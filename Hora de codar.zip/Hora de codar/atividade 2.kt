fun main(){

    println("Digite seu nome")
    var nomeDoUsuario= readln().toString()
   println("Olá, $nomeDoUsuario!")


}