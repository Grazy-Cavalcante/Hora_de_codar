fun main(){

    println ("Digite seu nome")
    var nomeDoUsuario= readln().toString()

    println("$nomeDoUsuario, Digite sua idade ")
    var idade= readln().toDouble()
    println("Olá, $nomeDoUsuario, sua idade é $idade!")


}